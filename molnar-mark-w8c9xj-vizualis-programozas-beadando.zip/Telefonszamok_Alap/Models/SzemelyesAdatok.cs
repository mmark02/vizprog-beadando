﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Telefonszamok_Alap.Models
{
    public class SzemelyesAdatok
    {
        public string Vezeteknev { get; set; }
        public string Utonev { get; set; }
        public string Irsz { get; set; }
        public string Helysegnev { get; set; }
        public string Lakcim { get; set; }
        public string Telefonszamok { get; set; }
    }
}
